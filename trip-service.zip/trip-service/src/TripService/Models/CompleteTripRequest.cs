namespace TripService.Models
{
    public class CompleteTripRequest
    {
        public decimal DistanceKm { get; set; }
    }
}
