namespace TripService.Models
{
    public class AssignDriverRequest
    {
        public int DriverId { get; set; }
    }
}
